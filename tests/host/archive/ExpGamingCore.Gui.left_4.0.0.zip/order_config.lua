return {
    'server-info',
    'readme',
    'science',
    'rockets',
    'player-list',
    'tasklist',
    'warp-list',
    'polls',
    'announcements',
    'admin-commands',
    'game-settings'
}