return {
    {"stone-wall",-10,-6},{"stone-wall",-10,-5},{"stone-wall",-10,-4},{"stone-wall",-10,-3},{"stone-wall",-10,-2},{"stone-wall",-10,-1},{"stone-wall",-10,0},{"stone-wall",-10,3},{"stone-wall",-10,4},{"stone-wall",-10,5},
    {"stone-wall",-10,6},{"stone-wall",-10,7},{"stone-wall",-10,8},{"stone-wall",-10,9},{"stone-wall",-8,-8},{"small-lamp",-8,-4},{"small-lamp",-8,-1},{"iron-chest",-8,0},{"iron-chest",-8,3},{"small-lamp",-8,4},
    {"small-lamp",-8,7},{"stone-wall",-8,11},{"stone-wall",-7,-8},{"small-electric-pole",-7,-2},{"iron-chest",-7,0},{"iron-chest",-7,3},{"small-electric-pole",-7,5},{"stone-wall",-7,11},{"stone-wall",-6,-8},{"small-lamp",-6,-6},
    {"iron-chest",-6,0},{"iron-chest",-6,3},{"small-lamp",-6,9},{"stone-wall",-6,11},{"stone-wall",-5,-8},{"small-lamp",-5,-1},{"iron-chest",-5,0},{"iron-chest",-5,3},{"small-lamp",-5,4},{"stone-wall",-5,11},
    {"stone-wall",-4,-8},{"small-electric-pole",-4,-5},{"iron-chest",-4,0},{"iron-chest",-4,3},{"small-electric-pole",-4,8},{"stone-wall",-4,11},{"stone-wall",-3,-8},{"small-lamp",-3,-6},{"small-lamp",-3,-3},{"small-lamp",-3,6},
    {"small-lamp",-3,9},{"stone-wall",-3,11},{"stone-wall",-2,-8},{"iron-chest",-2,-6},{"iron-chest",-2,-5},{"iron-chest",-2,-4},{"iron-chest",-2,-3},{"iron-chest",-2,-2},{"iron-chest",-2,5},{"iron-chest",-2,6},
    {"iron-chest",-2,7},{"iron-chest",-2,8},{"iron-chest",-2,9},{"stone-wall",-2,11},{"stone-wall",1,-8},{"iron-chest",1,-6},
    {"iron-chest",1,-5},{"iron-chest",1,-4},{"iron-chest",1,-3},{"iron-chest",1,-2},{"iron-chest",1,5},{"iron-chest",1,6},{"iron-chest",1,7},{"iron-chest",1,8},{"iron-chest",1,9},{"stone-wall",1,11},
    {"stone-wall",2,-8},{"small-lamp",2,-6},{"small-lamp",2,-3},{"small-lamp",2,6},{"small-lamp",2,9},{"stone-wall",2,11},{"stone-wall",3,-8},{"small-electric-pole",3,-5},{"iron-chest",3,0},{"iron-chest",3,3},
    {"small-electric-pole",3,8},{"stone-wall",3,11},{"stone-wall",4,-8},{"small-lamp",4,-1},{"iron-chest",4,0},{"iron-chest",4,3},{"small-lamp",4,4},{"stone-wall",4,11},{"stone-wall",5,-8},{"small-lamp",5,-6},
    {"iron-chest",5,0},{"iron-chest",5,3},{"small-lamp",5,9},{"stone-wall",5,11},{"stone-wall",6,-8},{"small-electric-pole",6,-2},{"iron-chest",6,0},{"iron-chest",6,3},{"small-electric-pole",6,5},{"stone-wall",6,11},
    {"stone-wall",7,-8},{"small-lamp",7,-4},{"small-lamp",7,-1},{"iron-chest",7,0},{"iron-chest",7,3},{"small-lamp",7,4},{"small-lamp",7,7},{"stone-wall",7,11},{"stone-wall",9,-6},{"stone-wall",9,-5},
    {"stone-wall",9,-4},{"stone-wall",9,-3},{"stone-wall",9,-2},{"stone-wall",9,-1},{"stone-wall",9,0},{"stone-wall",9,3},{"stone-wall",9,4},{"stone-wall",9,5},{"stone-wall",9,6},{"stone-wall",9,7},
    {"stone-wall",9,8},{"stone-wall",9,9}
}