return {
    ['refined-concrete']=true,
    ['refined-hazard-concrete-right']=true,
    ['refined-hazard-concrete-left']=true,
    ['concrete']=true,
    ['hazard-concrete-right']=true,
    ['hazard-concrete-left']=true,
    ['stone-path']=true
}